// src/firebase.js
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { addDoc, collection } from "firebase/firestore";

// Replace the config below with your project's values (already provided)
const firebaseConfig = {
  apiKey: "AIzaSyDHkLBtbW8R-9c5GYgtfWyk1Gz1N41lmO8",
  authDomain: "golf-swing-9b64e.firebaseapp.com",
  projectId: "golf-swing-9b64e",
  storageBucket: "golf-swing-9b64e.firebasestorage.app",
  messagingSenderId: "628769343061",
  appId: "1:628769343061:web:6aa5b4e682505e478bb6dc",
  measurementId: "G-PM3PGH4198"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const storage = getStorage(app);

/**
 * uploadSwingSession(videoBlob, poseFrames, meta)
 * - uploads videoBlob to Storage at swings/{id}.webm
 * - uploads poseFrames JSON to Storage at swings/{id}.json
 * - writes a Firestore document in 'swings' collection with metadata
 * returns { videoURL, poseURL, docId }
 */
export async function uploadSwingSession(videoBlob, poseFrames, meta = {}) {
  const timestamp = Date.now();
  const id = String(timestamp);
  const videoRef = ref(storage, `swings/${id}.webm`);
  const poseRef = ref(storage, `swings/${id}.json`);

  // upload video
  await uploadBytes(videoRef, videoBlob);
  const videoURL = await getDownloadURL(videoRef);

  // upload pose json blob
  const poseBlob = new Blob([JSON.stringify({ frames: poseFrames })], { type: "application/json" });
  await uploadBytes(poseRef, poseBlob);
  const poseURL = await getDownloadURL(poseRef);

  // save metadata to Firestore
  const doc = await addDoc(collection(db, "swings"), {
    id,
    timestamp,
    videoURL,
    poseURL,
    meta
  });

  return { videoURL, poseURL, docId: doc.id, id };
}
