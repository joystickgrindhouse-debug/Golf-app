// src/components/SwingPlayback.jsx
import React, { useRef, useEffect, useState } from "react";
import { drawSkeleton } from "./SkeletonOverlay";
import { db, storage } from "../firebase";
import { collection, getDocs, doc, getDoc } from "firebase/firestore";
import { ref, getDownloadURL } from "firebase/storage";

export default function SwingPlayback({ userSwingId }) {
  const [swings, setSwings] = useState([]);
  const [selected, setSelected] = useState(null);
  const [userPose, setUserPose] = useState([]);
  const [referencePose, setReferencePose] = useState([]);
  const [showOverlay, setShowOverlay] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [syncOffset, setSyncOffset] = useState(0);
  const [loading, setLoading] = useState(true);

  const userVideoRef = useRef();
  const refVideoRef = useRef();
  const userCanvasRef = useRef();
  const refCanvasRef = useRef();
  const frameIndexRef = useRef(0);

  useEffect(() => {
    const load = async () => {
      const snap = await getDocs(collection(db, "swings"));
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      data.sort((a,b)=>b.timestamp - a.timestamp);
      setSwings(data);
      setLoading(false);
    };
    load();
  }, []);

  useEffect(() => {
    if (!selected) return;
    (async () => {
      try {
        // load pose JSON from poseURL or doc
        let poseURL = selected.poseURL;
        if (!poseURL && selected.id) {
          const docRef = doc(db, 'swings', selected.id);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) poseURL = docSnap.data().poseURL;
        }
        if (poseURL) {
          const res = await fetch(poseURL);
          const json = await res.json();
          setUserPose(json.frames || json);
        }

        // load reference pose (local asset)
        const r = await fetch('/assets/reference_pose.json');
        const refPose = await r.json();
        setReferencePose(refPose);
      } catch (err) {
        console.error('Failed to load pose', err);
        setUserPose([]);
      }
    })();
  }, [selected]);

  useEffect(() => {
    if (userVideoRef.current) userVideoRef.current.playbackRate = speed;
    if (refVideoRef.current) refVideoRef.current.playbackRate = speed;
  }, [speed]);

  useEffect(() => {
    if (loading) return;
    let raf = null;
    const uCtx = userCanvasRef.current && userCanvasRef.current.getContext('2d');
    const rCtx = refCanvasRef.current && refCanvasRef.current.getContext('2d');

    function drawLoop() {
      if (!showOverlay) {
        if (uCtx) uCtx.clearRect(0,0,userCanvasRef.current.width, userCanvasRef.current.height);
        if (rCtx) rCtx.clearRect(0,0,refCanvasRef.current.width, refCanvasRef.current.height);
        raf = requestAnimationFrame(drawLoop);
        return;
      }
      if (userVideoRef.current && uCtx) {
        uCtx.clearRect(0,0,userCanvasRef.current.width, userCanvasRef.current.height);
        drawSkeleton(uCtx, userPose, userVideoRef.current.currentTime*1000);
      }
      if (refVideoRef.current && rCtx) {
        rCtx.clearRect(0,0,refCanvasRef.current.width, refCanvasRef.current.height);
        drawSkeleton(rCtx, referencePose, refVideoRef.current.currentTime*1000 + syncOffset*1000);
      }
      raf = requestAnimationFrame(drawLoop);
    }
    raf = requestAnimationFrame(drawLoop);
    return () => cancelAnimationFrame(raf);
  }, [userPose, referencePose, showOverlay, loading, syncOffset, speed]);

  return (
    <div style={{maxWidth:960, margin:'0 auto', textAlign:'center'}}>
      <h3>Swing Playback</h3>
      <div style={{display:'flex', gap:12, justifyContent:'center', marginBottom:8}}>
        <button onClick={() => {
          if (!selected) return;
          const u = userVideoRef.current, r = refVideoRef.current;
          if (u.paused) { u.play(); r.play(); } else { u.pause(); r.pause(); }
        }}>▶️ / ⏸️</button>
        <button onClick={() => setShowOverlay(v=>!v)}>{showOverlay ? 'Hide Overlay' : 'Show Overlay'}</button>
        <label>Speed:
          <input type="range" min="0.25" max="2" step="0.25" value={speed} onChange={(e)=>setSpeed(parseFloat(e.target.value))} />
          {speed}x
        </label>
        <label>Sync:
          <input type="range" min="-1" max="1" step="0.05" value={syncOffset} onChange={(e)=>setSyncOffset(parseFloat(e.target.value))} />
          {syncOffset}s
        </label>
      </div>

      <div style={{display:'flex', gap:12}}>
        <div style={{flex:1, textAlign:'left'}}>
          <h4>Recorded Swings</h4>
          <ul>
            {swings.map(s => (
              <li key={s.id} style={{marginBottom:6}}>
                <button onClick={() => setSelected(s)}>{new Date(s.timestamp).toLocaleString()}</button>
              </li>
            ))}
          </ul>
        </div>

        <div style={{flex:2}}>
          {selected ? (
            <div style={{display:'flex', gap:12}}>
              <div style={{position:'relative', width:320, height:180, background:'#000'}}>
                <video ref={userVideoRef} src={selected.videoURL} width="320" height="180" controls playsInline />
                <canvas ref={userCanvasRef} width={320} height={180} style={{position:'absolute', left:0, top:0, pointerEvents:'none'}} />
                <div style={{position:'absolute', left:8, top:8, color:'#fff', background:'#0008', padding:'2px 6px', borderRadius:6}}>Your Swing</div>
              </div>

              <div style={{position:'relative', width:320, height:180, background:'#000'}}>
                <video ref={refVideoRef} src={'/assets/reference_swing.mp4'} width="320" height="180" controls playsInline />
                <canvas ref={refCanvasRef} width={320} height={180} style={{position:'absolute', left:0, top:0, pointerEvents:'none'}} />
                <div style={{position:'absolute', left:8, top:8, color:'#fff', background:'#0008', padding:'2px 6px', borderRadius:6}}>Reference</div>
              </div>
            </div>
          ) : <p>Select a swing to play.</p>}
        </div>
      </div>
    </div>
  );
}
