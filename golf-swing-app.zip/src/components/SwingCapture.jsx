// src/components/SwingCapture.jsx
import React, { useEffect, useRef, useState } from "react";
import { Pose } from "@mediapipe/pose";
import { Camera } from "@mediapipe/camera_utils";
import { drawConnectors, drawLandmarks } from "@mediapipe/drawing_utils";
import { POSE_CONNECTIONS } from "@mediapipe/pose";
import { uploadSwingSession } from "../firebase";

export default function SwingCapture({ onUpload }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const cameraRef = useRef(null);
  const poseRef = useRef(null);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);
  const poseFramesRef = useRef([]);
  const [status, setStatus] = useState("Initializing...");
  const [isRecording, setIsRecording] = useState(false);

  const FPS = 30;
  const VELOCITY_THRESHOLD = 0.04;
  const MIN_RECORD_MS = 300;
  const COOLDOWN_MS = 1000;

  const prevPoseRef = useRef(null);
  const swingingRef = useRef(false);
  const swingStartRef = useRef(0);
  const lastFinishRef = useRef(0);

  useEffect(() => {
    let mounted = true;
    (async () => {
      setStatus("Starting camera & pose...");
      const pose = new Pose({ locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}` });
      pose.setOptions({
        modelComplexity: 1,
        smoothLandmarks: true,
        enableSegmentation: false,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5,
      });
      poseRef.current = pose;

      pose.onResults((results) => {
        if (!mounted) return;
        const vid = videoRef.current;
        const canvas = canvasRef.current;
        if (!canvas || !vid) return;
        const ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(results.image, 0, 0, canvas.width, canvas.height);

        if (results.poseLandmarks) {
          drawConnectors(ctx, results.poseLandmarks, POSE_CONNECTIONS, { color: "#00FF00", lineWidth: 3 });
          drawLandmarks(ctx, results.poseLandmarks, { color: "#FF0000", lineWidth: 2 });

          const curr = {
            left_wrist: results.poseLandmarks[15],
            right_wrist: results.poseLandmarks[16],
            left_shoulder: results.poseLandmarks[11],
            right_shoulder: results.poseLandmarks[12],
          };

          const prev = prevPoseRef.current;
          const now = performance.now();
          let avgSpeed = 0;
          if (prev) {
            const lw = distance(prev.left_wrist, curr.left_wrist);
            const rw = distance(prev.right_wrist, curr.right_wrist);
            avgSpeed = (lw + rw) / 2;
          }

          const sinceLastFinish = now - lastFinishRef.current;
          const canStart = sinceLastFinish > COOLDOWN_MS;

          if (!swingingRef.current && canStart && avgSpeed > VELOCITY_THRESHOLD) {
            // start
            swingingRef.current = true;
            swingStartRef.current = now;
            poseFramesRef.current = [];
            startMediaRecorder();
            setIsRecording(true);
            setStatus("Swing detected — recording...");
          }

          if (swingingRef.current) {
            const tRel = now - swingStartRef.current;
            poseFramesRef.current.push({ t: tRel, keypoints: results.poseLandmarks });
          }

          if (swingingRef.current && avgSpeed < VELOCITY_THRESHOLD * 0.6) {
            const duration = now - swingStartRef.current;
            if (duration >= MIN_RECORD_MS) finishRecording();
          }

          prevPoseRef.current = curr;
        } else {
          prevPoseRef.current = null;
        }
      });

      const cam = new Camera(videoRef.current, {
        onFrame: async () => {
          if (!poseRef.current) return;
          await poseRef.current.send({ image: videoRef.current });
        },
        width: 640,
        height: 480,
        facingMode: "environment",
      });
      cameraRef.current = cam;
      await cam.start();
      setStatus("Ready — waiting for swing");
    })();

    return () => {
      mounted = false;
      cameraRef.current && cameraRef.current.stop && cameraRef.current.stop();
      poseRef.current && poseRef.current.close && poseRef.current.close();
      stopRecorderIfActive();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function distance(a = {}, b = {}) {
    if (!a || !b || a.x == null || b.x == null) return 0;
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  function startMediaRecorder() {
    try {
      const videoEl = videoRef.current;
      const canvasEl = canvasRef.current;
      if (!videoEl) throw new Error("No video element");

      let stream = null;
      if (videoEl.captureStream) {
        stream = videoEl.captureStream(FPS);
        console.log("Using video.captureStream()");
      } else if (canvasEl && canvasEl.captureStream) {
        stream = canvasEl.captureStream(FPS);
        console.log("Fallback to canvas.captureStream()");
      } else {
        throw new Error("captureStream not supported");
      }

      const options = { mimeType: "video/webm;codecs=vp8,opus" };
      const mr = new MediaRecorder(stream, options);
      chunksRef.current = [];

      mr.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
      };

      mr.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: "video/webm" });
        const poseFrames = poseFramesRef.current.slice();
        setStatus("Uploading swing to Firebase...");
        try {
          const res = await uploadSwingSession(blob, poseFrames, { device: "iOS18" });
          setStatus("Upload complete");
          if (onUpload && res && res.id) onUpload(res.id);
        } catch (err) {
          console.error("Upload failed", err);
          setStatus("Upload failed");
        }
        chunksRef.current = [];
        poseFramesRef.current = [];
      };

      recorderRef.current = mr;
      mr.start();
    } catch (err) {
      console.warn("Recording failed, falling back to pose-only", err);
      setStatus("Pose-only: recording skipped, saving pose data only.");
      recorderRef.current = null;
    }
  }

  function finishRecording() {
    if (recorderRef.current) {
      try { recorderRef.current.stop(); } catch (e) {}
    } else {
      // pose-only: upload poseFrames as JSON
      const poseFrames = poseFramesRef.current.slice();
      (async () => {
        try {
          setStatus("Uploading pose-only swing...");
          const res = await uploadSwingSession(new Blob([], { type: 'video/webm' }), poseFrames, { device: "pose-only" });
          setStatus("Upload complete (pose-only)");
          if (onUpload && res && res.id) onUpload(res.id);
        } catch (err) {
          console.error("Pose-only upload failed", err);
          setStatus("Upload failed");
        }
        poseFramesRef.current = [];
      })();
    }
    lastFinishRef.current = performance.now();
    swingingRef.current = false;
    setIsRecording(false);
  }

  function stopRecorderIfActive() {
    if (recorderRef.current && recorderRef.current.state !== "inactive") {
      try { recorderRef.current.stop(); } catch (e) {}
    }
  }

  return (
    <div style={{textAlign:'center', maxWidth:760, margin:'0 auto'}}>
      <h3>Auto Swing Capture (iOS Hybrid)</h3>
      <p>{status}</p>
      <div style={{position:'relative', width:640, height:480, margin:'auto'}}>
        <video ref={videoRef} autoPlay playsInline muted width="640" height="480" style={{objectFit:'cover'}} />
        <canvas ref={canvasRef} width={640} height={480} style={{position:'absolute', left:0, top:0, pointerEvents:'none'}} />
      </div>
      <div style={{marginTop:12}}>
        <small>Automatic detection running — swing when ready. You can press 'Stop Recording' to force-stop.</small>
      </div>
      <div style={{marginTop:12}}>
        <button onClick={()=>{ if (isRecording) finishRecording(); }}>Stop Recording (manual)</button>
      </div>
    </div>
  );
}
