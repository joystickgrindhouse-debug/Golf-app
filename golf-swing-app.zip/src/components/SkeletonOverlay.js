// src/components/SkeletonOverlay.js
export function drawSkeleton(ctx, poseFrames, currentTimeMs) {
  if (!poseFrames || !poseFrames.length) return;
  // find nearest frame (poseFrames use t in ms)
  let best = poseFrames[0];
  let bestDiff = Math.abs(best.t - currentTimeMs);
  for (let i = 1; i < poseFrames.length; i++) {
    const d = Math.abs(poseFrames[i].t - currentTimeMs);
    if (d < bestDiff) { best = poseFrames[i]; bestDiff = d; }
  }
  if (!best || !best.keypoints) return;

  const kp = best.keypoints;
  ctx.strokeStyle = 'rgba(0,255,0,0.9)';
  ctx.lineWidth = 3;

  const links = [
    [11,13],[13,15],
    [12,14],[14,16],
    [11,12],[23,24],
    [11,23],[12,24],
    [23,25],[25,27],
    [24,26],[26,28]
  ];

  for (const [a,b] of links) {
    if (kp[a] && kp[b]) {
      ctx.beginPath();
      ctx.moveTo(kp[a].x * ctx.canvas.width, kp[a].y * ctx.canvas.height);
      ctx.lineTo(kp[b].x * ctx.canvas.width, kp[b].y * ctx.canvas.height);
      ctx.stroke();
    }
  }
}
