import React from 'react'
import SwingCapture from './components/SwingCapture'
import SwingPlayback from './components/SwingPlayback'

export default function App(){
  const [route, setRoute] = React.useState('capture')
  const [lastUploadedId, setLastUploadedId] = React.useState(null)

  return (
    <div style={{fontFamily:'Inter, system-ui, Arial', padding:12}}>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h2>Golf Swing Tracker (iOS hybrid)</h2>
        <div>
          <button onClick={()=>setRoute('capture')}>Capture</button>
          <button onClick={()=>setRoute('playback')}>Playback</button>
        </div>
      </header>

      <main style={{marginTop:12}}>
        {route === 'capture' ? <SwingCapture onUpload={(id)=>setLastUploadedId(id)} /> :
          <SwingPlayback userSwingId={lastUploadedId} />
        }
      </main>
    </div>
  )
}
